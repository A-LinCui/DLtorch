from DLtorch.models.Cifar10.DenseNet import *
from DLtorch.models.Cifar10.LeNet import LeNet
from DLtorch.models.Cifar10.WideResNet import WideResNet
from DLtorch.models.Cifar10.resnet import *