from DLtorch.datasets.base import base_dataset
from DLtorch.datasets.Cifar10 import Cifar10