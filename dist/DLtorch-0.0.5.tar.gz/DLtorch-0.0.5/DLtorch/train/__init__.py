from DLtorch.train.CNNFinalTrainer import CNNFinalTrainer
from DLtorch.train.base import BaseFinalTrainer